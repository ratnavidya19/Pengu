#!/bin/bash
javac PenguAction.java
java PenguAction $1 $2
